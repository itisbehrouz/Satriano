---
name: Heritage Atelier
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#47464f'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#777680'
  outline-variant: '#c8c5d0'
  surface-tint: '#595990'
  primary: '#000005'
  on-primary: '#ffffff'
  primary-container: '#151449'
  on-primary-container: '#7f7eb9'
  inverse-primary: '#c2c1ff'
  secondary: '#765a1e'
  on-secondary: '#ffffff'
  secondary-container: '#ffd78f'
  on-secondary-container: '#795c20'
  tertiary: '#000001'
  on-tertiary: '#ffffff'
  tertiary-container: '#121d25'
  on-tertiary-container: '#7a858f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c2c1ff'
  on-primary-fixed: '#151449'
  on-primary-fixed-variant: '#414177'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e7c17b'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5c4206'
  tertiary-fixed: '#d8e4ef'
  tertiary-fixed-dim: '#bcc8d3'
  on-tertiary-fixed: '#121d25'
  on-tertiary-fixed-variant: '#3d4851'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.03em
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style
The design system is anchored in the concept of "The Bespoke Contract." It merges the meticulous craft of high-end tailoring with the logistical precision of B2B manufacturing. The visual language avoids the coldness of industrial tech and the flightiness of fast fashion, instead favoring a stable, authoritative, and heritage-focused aesthetic.

The style is a blend of **Modern Minimalism** and **Classical Editorial**. It utilizes generous whitespace, precise geometric framing, and high-contrast typography to evoke the feeling of a premium physical lookbook or a prestigious ledger. Surfaces are treated like fabric—clean, structured, and intentional.

## Colors
The palette is rooted in traditional sartorial tones. 

- **Primary (Deep Navy):** Used for foundational elements like headers, footers, and primary text to establish authority.
- **Accent (Warm Gold):** Reserved for high-priority actions, focus states, and decorative "stitch" lines. It represents quality and craftsmanship.
- **Secondary (Slate Gray-Blue):** Used for supporting UI elements, metadata, and muted background sections to provide depth without competing with the navy.
- **Neutral (Cream):** The primary canvas color. It is softer and more premium than pure white, providing a "parchment" feel that enhances readability and luxury.

## Typography
Typography is the primary vehicle for the brand’s heritage. **Playfair Display** provides the editorial, high-contrast serif look necessary for B2B trust and luxury positioning. **Inter** serves as the functional workhorse, providing clarity for technical specifications and order details. 

Labels and small UI descriptors should frequently use uppercase with increased letter-spacing to mimic the look of garment tags and industrial stamps.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to maintain a composed, "framed" appearance. Large margins are encouraged to create a sense of exclusivity.

- **Grid:** A 12-column system with 24px gutters.
- **Rhythm:** Spacing follows an 8px base unit. Component padding should be generous (typically 24px or 32px) to prevent the UI from feeling cluttered or "cheap."
- **Dividers:** Use thin (1px) rule lines in Gold or Slate to separate sections, mimicking the precision of a tailor’s markings.

## Elevation & Depth
This design system avoids heavy shadows and floating effects. Depth is achieved through **Tonal Layering** and **Structural Framing**.

- **Surface Levels:** The Cream background acts as the base. Slate Gray-Blue is used for inset containers or subtle section changes. Deep Navy is used for "elevated" persistent navigation.
- **Outlines:** Instead of shadows, use 1px solid borders in Gold or low-opacity Navy to define object boundaries. 
- **Glassmorphism:** Use sparingly for navigation overlays (Deep Navy with 80% opacity and 12px blur) to maintain visibility over high-quality textile imagery.

## Shapes
The shape language is strictly **Sharp**. Right angles convey the precision of pattern cutting and architectural stability. Circles and high-radius curves are avoided to distinguish the product from consumer-grade, "soft" web apps. Rectangular frames with thin gold borders are the signature container style.

## Components

### Buttons
- **Primary:** Solid Warm Gold (#DBB671) background with Deep Navy (#151449) text. Sharp corners.
- **Secondary:** Transparent background with a 1px Gold border. Text in Gold.
- **Tertiary/Ghost:** Deep Navy text with a 1px Gold underline that expands on hover.

### Cards & Containers
- **Content Cards:** Cream background with a 1px Gold or Slate border. No shadows.
- **Feature Cards:** Deep Navy background with Gold rule lines at the top or bottom for emphasis.

### Form Fields
- **Inputs:** 1px Slate border on Cream background. On focus, the border transitions to 1px Gold with a very subtle Gold "glow" (not a shadow, but a soft outer line).
- **Labels:** Inter, Bold, Uppercase, 12px, Deep Navy.

### Navigation
- **Top Bar:** Deep Navy background. All navigation links in Inter, Medium, Uppercase with 0.1em letter spacing.
- **Active State:** A thin Gold horizontal line above the active menu item.

### Specialized Components
- **Spec Sheet Lists:** Technical data tables should use thin Slate borders and alternating Cream/Light-Slate row backgrounds to ensure legibility for manufacturing orders.
- **Status Chips:** Rectangular, sharp-edged chips with Slate backgrounds and Navy text for neutral states; Gold backgrounds for "Active" or "Priority" states.